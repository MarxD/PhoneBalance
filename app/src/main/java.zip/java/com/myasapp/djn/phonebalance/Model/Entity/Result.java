package com.myasapp.djn.phonebalance.Model.Entity;

/**
 * Created by DJN on 2016/8/2.
 */
public class Result {
    private String phonenumber;
    private String iccid;
    private String cardpackage;
    private double totalGPRS;
    private double used;
    private double balance;
    private int statu;
    private double surplus;

    public Result(){};
    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getIccid() {
        return iccid;
    }

    public void setIccid(String iccid) {
        this.iccid = iccid;
    }

    public String getCardpackage() {
        return cardpackage;
    }

    public void setCardpackage(String cardpackage) {
        this.cardpackage = cardpackage;
    }

    public double getTotalGPRS() {
        return totalGPRS;
    }

    public void setTotalGPRS(double totalGPRS) {
        this.totalGPRS = totalGPRS;
    }

    public double getUsed() {
        return used;
    }

    public void setUsed(double used) {
        this.used = used;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getStatu() {
        return statu;
    }

    public void setStatu(int statu) {
        this.statu = statu;
    }

    public double getSurplus() {
        return surplus;
    }

    public void setSurplus(double surplus) {
        this.surplus = surplus;
    }
}
