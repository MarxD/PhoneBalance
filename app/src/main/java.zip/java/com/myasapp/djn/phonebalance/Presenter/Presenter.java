package com.myasapp.djn.phonebalance.Presenter;

import com.myasapp.djn.phonebalance.Model.Entity.Result;
import com.myasapp.djn.phonebalance.Model.Model;
import com.myasapp.djn.phonebalance.Presenter.Interface.PreserterInterface;
import com.myasapp.djn.phonebalance.Presenter.Interface.onLoadInformationListener;
import com.myasapp.djn.phonebalance.View.MainView;

/**
 * Created by Administrator on 2016/8/5.
 */
public class Presenter implements PreserterInterface,onLoadInformationListener {

    private MainView main;
    private Model model;
    public Presenter(MainView main)
    {
        this.main = main;
        model = new Model();
    }

    @Override
    public void getInformation(String PhoneNumber) {
        if(Model.isSending)
        {
            return;
        }
        main.Loading();
        model.sendRequest(PhoneNumber,this);
    }

    @Override
    public void onSuccess(Result result) {
        main.setData(result);
    }

    @Override
    public void onFaild(String errorMsg) {
        main.showError(errorMsg);
    }
}
