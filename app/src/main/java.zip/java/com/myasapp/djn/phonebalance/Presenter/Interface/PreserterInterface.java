package com.myasapp.djn.phonebalance.Presenter.Interface;

/**
 * Created by Administrator on 2016/8/5.
 */
public interface PreserterInterface {

    public void getInformation(String PhoneNumber);
}
