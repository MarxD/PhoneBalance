package com.myasapp.djn.phonebalance.Model;

import android.os.AsyncTask;
import android.util.Log;

import com.myasapp.djn.phonebalance.Model.Entity.Result;
import com.myasapp.djn.phonebalance.Model.Interface.ModelInteface;
import com.myasapp.djn.phonebalance.Presenter.Interface.onLoadInformationListener;

import org.json.JSONObject;
import org.jsoup.Jsoup;

import java.math.BigDecimal;

/**
 * Created by Administrator on 2016/8/5.
 */
public class Model implements ModelInteface {
    public static boolean isSending = false;
    onLoadInformationListener listener;
    @Override
    public void sendRequest(final String phoneNumber, final onLoadInformationListener listener) {
        isSending = true;
        this.listener = listener;
        new sender().execute(phoneNumber);
    }

    private class sender extends AsyncTask<String,Void,Boolean>
    {
        Result myResult;
        String errorMsg;
        @Override
        protected Boolean doInBackground(String... params) {
            try {
            myResult = new Result();
            String result = Jsoup.connect("http://123.57.18.0:8080/api/wechat/simcards/"+params[0]).ignoreContentType(true).timeout(5000).get().body().text();
            JSONObject root = new JSONObject(result);
            myResult.setPhonenumber(root.getString("phoneno"));
            myResult.setBalance(root.getJSONObject("balance").getJSONArray("result").getJSONObject(0).getDouble("balance"));
            int code =root.getJSONObject("userstatus").getJSONArray("result").getJSONObject(0).getInt("STATUS");
            myResult.setStatu(code);
            double double_used = root.getJSONObject("gprsrealtime").getJSONArray("result").getJSONObject(0).getJSONArray("gprs").getJSONObject(0).getDouble("used")/1024;
            myResult.setUsed(new BigDecimal(double_used).setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue());
            myResult.setTotalGPRS(root.getJSONObject("gprsrealtime").getJSONArray("result").getJSONObject(0).getJSONArray("gprs").getJSONObject(0).getDouble("total"));
            Double MB = myResult.getTotalGPRS()-myResult.getUsed();
            myResult.setSurplus(new BigDecimal(MB).setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue());
            myResult.setCardpackage(root.getString("cardpackage"));
            return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
            finally {
                isSending = false;
            }
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            if(aBoolean)
            {
                listener.onSuccess(myResult);
            }
            else
            {
                listener.onFaild(errorMsg);
            }
        }
    }
}
